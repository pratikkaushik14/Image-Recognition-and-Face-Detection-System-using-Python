Where did the file go? We update this page depending on if we made changes to the repo that are different than our guides and/or tutorials both on [joincfe.com/youtube/](joincfe.com/youtube/) and [joincfe.com/blog/](joincfe.com/blog/).


`trainner.yml` is now in `recognizers/face-trainner.yml`

`watermark_lesson.py` is now in `lessons/watermark_lesson.py`

`record-video.py` is now in `lessons/record-video.py`